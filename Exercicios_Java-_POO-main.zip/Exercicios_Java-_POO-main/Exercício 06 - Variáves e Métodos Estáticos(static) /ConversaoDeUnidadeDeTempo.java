package Exercicios.java;

public class ConversaoDeUnidadesDeTempo {

    public static int minutosParaSegundos(int minutos){
        return minutos * 60;
    }
    public static int horasParaMinutos(int horas){
        return horas * 60;
    }
    public static int diasParaHoras(int dias){
        return dias * 24;
    }
    public static int semanasParaDias(int semanas){
        return semanas * 7;
    }
    public static int mesesParaDias(int meses){
        return meses * 30;
    }
}
