    package Exercicios.java;

    import java.util.Scanner;

    public class Main {

        public static void main(String[] args) {
          imprimirTela(Calculadora.somatorio(15));
        }
        static void imprimirTela(int num){
            System.out.println(num);
        }
    }