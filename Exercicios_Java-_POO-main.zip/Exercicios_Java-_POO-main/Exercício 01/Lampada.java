package Exercicios.java;

public class Lampada {
    String marca;
    double voltagem;
    String tipo;
    String modelo;
    String Cor;
    double Preço;
    int Garantia;
}
