package Exercicios.java;

public class ConversaoDeUnidadeDeArea {

    public static double metroParaPes(double metro){
        return metro * 10.76;
    }
    public static double pesParaCentimetros(double pes){
        return pes * 929;
    }
    public static double milhaParaAcres(double milha){
        return milha * 640;
    }
    public static double acresParaPes(double acres){
        return acres * 43.560;
    }

}
