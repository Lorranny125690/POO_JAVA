package Exercicios.java;

public class Contato {
    String nome;
    String email;
    String telefones [];
    boolean ativo;
    String endereco;
}
