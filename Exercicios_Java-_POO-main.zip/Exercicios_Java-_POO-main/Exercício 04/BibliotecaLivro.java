package Exercicios.java;

import java.util.Date;

public class BibliotecaLivro {
    String nome;
    String autor;
    int qtdPaginas;
    int anoLancamento;
    String isbn;
    double preco;

    boolean emprestado;
    Date dataEntrega;
    String emprestadoA;
}
