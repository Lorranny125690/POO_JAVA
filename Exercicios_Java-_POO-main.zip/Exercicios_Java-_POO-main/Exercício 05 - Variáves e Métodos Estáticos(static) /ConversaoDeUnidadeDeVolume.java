package Exercicios.java;

public class ConversaoDeUnidadeDeVolume {
    public static double litroParaCentimetrosCubicos(double litros){
        return litros * 1000;
    }
    public static double metrosCubicosParaLitros(double metros){
        return metros * 1000;
    }
    public static double metrosCubicosParaPesCubicos(double metros){
        return metros * 35.32;
    }
    public static double galaoAmericanoParaPolegadasCubicas(double galao){
        return galao * 231;
    }
    public static double galaoAmericanoParaLitros(double galao){
        return galao * 3.785;
    }
}
