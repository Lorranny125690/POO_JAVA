package Exercicios.java;

public class ContaCorrente {
    int numConta;
    String nome;
    String banco;
    boolean especial;
    double limiteEspecial;
    double saldo;
}
