package Exercicios.java;

import java.util.Date;

public class LivroLivraria {
    String nome;
    String autor;
    int qtdPaginas;
    int anoLancamento;
    String isbn;
    double preco;
}
