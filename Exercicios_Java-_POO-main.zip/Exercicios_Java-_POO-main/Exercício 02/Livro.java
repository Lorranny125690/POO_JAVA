package Exercicios.java;

public class Livro {
    String nome;
    String autor;
    String editora;
    int qtdPaginas;
    String categoria;
    String Genero;
    String idiomaOriginal;
}
