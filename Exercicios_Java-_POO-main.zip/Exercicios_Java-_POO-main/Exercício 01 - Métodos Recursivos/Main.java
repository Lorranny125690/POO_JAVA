    package Exercicios.java;

    import java.util.Scanner;

    public class Main {

        public static void main(String[] args) {
          imprimirTela(Calculadora.fibonacci(8));
        }
        static void imprimirTela(int num){
            System.out.println(num);
        }
    }